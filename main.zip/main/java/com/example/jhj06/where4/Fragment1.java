package com.example.jhj06.where4;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

/**
 * Created by jhj06 on 2017-12-17.
 */

public class Fragment1 extends android.support.v4.app.Fragment{

    //EditText et;
    ImageButton btnVoice, btnText;
    TextView tv;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //xml과 연결
        final ViewGroup  rootview=(ViewGroup)inflater.inflate(R.layout.f1,container,false);

      //  et=(EditText)rootview.findViewById(R.id.etText);//시


        btnText=(ImageButton)rootview.findViewById(R.id.btnText);
        btnText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TMapPoint map=translatePoint("삼양로144길 19-7");
                // et.setText(map.getLongitude()+", "+map.getLatitude());
            }
        });
        tv=(TextView)rootview.findViewById(R.id.tv);
        btnVoice=(ImageButton) rootview.findViewById(R.id.btnVoice);

        btnVoice.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
//                Intent intent=new Intent(rootview.getContext(), MapActivity.class);
//                intent.putExtra("address","삼양로144길 19-7");
//                startActivity(intent);

            }
        });
        return rootview;
    }

}
