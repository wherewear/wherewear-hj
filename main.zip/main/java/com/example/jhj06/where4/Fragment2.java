package com.example.jhj06.where4;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by jhj06 on 2017-12-17.
 */

public class Fragment2 extends android.support.v4.app.Fragment{

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //xml과 연결
        ViewGroup  rootview=(ViewGroup)inflater.inflate(R.layout.f2,container,false);

        return rootview;
    }

}
