package com.example.jhj06.where4;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.skp.Tmap.TMapData;
import com.skp.Tmap.TMapPoint;
import com.skp.Tmap.TMapPolyLine;
import com.skp.Tmap.TMapView;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.IOException;
import java.util.List;


public class MapActivity extends AppCompatActivity {

    String pathText;

    RelativeLayout container;
    TextView tv1;
    String sec="";

    TMapView tMapView;
//    boolean flag=true;

    TextToSpeech tts;

    TMapPoint startPoint=new TMapPoint(37.651445,127.016160);
   TMapPoint destPoint=new TMapPoint(37.637696,127.024636);
   // TMapPoint destPoint;

    TMapData tmapdata;

    Intent intent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);


        tmapdata=new TMapData();

        container=(RelativeLayout) findViewById(R.id.container);
        //선언
        tMapView=new TMapView(this);
        intent=getIntent();

        //목적지 좌표 설정
     //   destPoint=translatePoint(intent.getStringExtra("address"));
        tv1=(TextView)findViewById(R.id.pathText);

        initTMapView();

        container.addView(tMapView);
    }
    //tmap view
    public void initTMapView(){

        //키값
        tMapView.setSKPMapApiKey("2d662269-193b-3f0d-8c35-fde796e55dbf");

        tMapView.setCenterPoint(127.016160,37.651445);

        tMapView.setOnApiKeyListener(new TMapView.OnApiKeyListenerCallback() {
            @Override
            public void SKPMapApikeySucceed() {
                Log.d("map auth","success");
            }

            @Override
            public void SKPMapApikeyFailed(String s) {
                Log.d("Map Auth",s);
            }
        });

        //경로 그리기
        tmapdata.findPathData(startPoint, destPoint, new TMapData.FindPathDataListenerCallback() {
            @Override
            public void onFindPathData(TMapPolyLine tMapPolyLine) {
                tMapPolyLine.setLineWidth(10);
                tMapView.addTMapPath(tMapPolyLine);
            }
        });

        //경로 텍스트
        tmapdata.findPathDataAllType(TMapData.TMapPathType.PEDESTRIAN_PATH, startPoint, destPoint, new TMapData.FindPathDataAllListenerCallback() {

            @Override

            public void onFindPathDataAll(Document document) {
                //backThread thread=new backThread();

                Element root = document.getDocumentElement();

                NodeList nodeListPlacemark = root.getElementsByTagName("Placemark");

                for( int i=0; i<nodeListPlacemark.getLength(); i++ ) {

                    NodeList nodeListPlacemarkItem = nodeListPlacemark.item(i).getChildNodes();

                    for( int j=0; j<nodeListPlacemarkItem.getLength(); j++ ) {


                        if( nodeListPlacemarkItem.item(j).getNodeName().equals("description") ) {
                            if(nodeListPlacemarkItem.item(j).getTextContent().trim().toString().length()>0){
                                pathText=nodeListPlacemarkItem.item(j).getTextContent().trim().toString();

//                                if(!flag){
                                    sec="";
                                    for(int k=0;k<pathText.length();k++){
                                        if(isStringDouble(pathText.charAt(k)+"")){
                                            if(sec.length()>0){
                                                if(!isStringDouble(pathText.charAt(k-1)+"")){
                                                    sec="";
                                                }
                                            }
                                            sec+=pathText.charAt(k);
                                        }
                                     }
//                                    pathText=sec;
//                            }
                                setTextSpeech();
//                                flag=!flag;
                            }
                        }
                    }
                }




            }

        });



    }


    //주소->좌표로 변환해 반환
    public TMapPoint translatePoint(String address){
        TMapPoint tmap=null;
        List<Address> list=null;
        Geocoder geocoder=new Geocoder(getApplication());
        try{
            list=geocoder.getFromLocationName(address,10);
        }catch (IOException e){
            e.printStackTrace();
        }
        if(list!=null){
            if(list.size()==0) {
                Toast.makeText(getApplicationContext(), "해당주소정보없음", Toast.LENGTH_LONG).show();
            }else{
                Address addr=list.get(0);
                double lat = addr.getLatitude();
                double lon = addr.getLongitude();

                tmap=new TMapPoint(lat,lon);
            }
        }

        return  tmap;
    }
    boolean isStringDouble(String str){
        try{
            Integer.parseInt(str);
            return true;
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return false;
    }



    //text 수정 후 말해주기 tts사용
    public void setTextSpeech(){

        try{
            //경로 textview에 갱신
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    tv1.setText(pathText);

                }
            });
            //tts 통해 말해주기
            tts=new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int status) {
                    tts.speak(pathText,TextToSpeech.QUEUE_FLUSH, null);
                }
            });

            Thread.sleep(Integer.parseInt(sec)*700);//1m당 1초 쉬기
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //activity 소멸하면 tts도 소멸해줘야 한다.
        tts.shutdown();
    }
}
